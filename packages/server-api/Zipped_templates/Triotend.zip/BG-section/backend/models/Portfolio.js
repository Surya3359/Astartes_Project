const mongoose = require('mongoose');

// Define the Portfolio schema
const portfolioSchema = new mongoose.Schema(
  {
    sectitle: {
      type: String,
      required: true, // Ensure every document has a section title
    },
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      enum: ['Mobile Apps', 'ChatBots', 'Web Apps'], // Example categories
      required: true,
    },
    image: {
      type: String, // URL to the image file
      required: true,
    },
  },
  {
    timestamps: true, // Adds createdAt and updatedAt fields
  }
);

const Portfolio = mongoose.model('Portfolio', portfolioSchema);

module.exports = Portfolio;
