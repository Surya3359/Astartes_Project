const mongoose = require('mongoose');

const heroSchema = mongoose.Schema({
  title: { type: String, required: true },
  subtitle: { type: String, required: true },
  videoLink: { type: String, required: true },
  image: { type: String, default: '' },
});

module.exports = mongoose.model('Hero', heroSchema);
