const express = require('express');
const multer = require('multer');
const Portfolio = require('../models/Portfolio');
const router = express.Router();

// Configure Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ storage });

// Get all portfolio items
router.get('/', async (req, res) => {
  try {
    const portfolioItems = await Portfolio.find();
    res.json(portfolioItems);
  } catch (error) {
    res.status(500).json({ message: "Error fetching portfolio items", error });
  }
});

// Add a new portfolio item
router.post('/', upload.single('image'), async (req, res) => {
  try {
    const { title, description, category } = req.body;
    const newPortfolio = new Portfolio({
      title,
      description,
      category,
      image: `/uploads/${req.file.filename}`,
    });
    const savedPortfolio = await newPortfolio.save();
    res.status(201).json(savedPortfolio);
  } catch (error) {
    res.status(500).json({ message: "Error adding portfolio item", error });
  }
});

// Get distinct categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await Portfolio.distinct('category'); // Fetch unique categories
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: "Error fetching categories", error });
  }
});

// Get section title (optional - static or dynamic example)
router.get('/title', async (req, res) => {
  try {
    // If dynamic, fetch from DB or config
    const title = await Portfolio.distinct('sectitle'); // Replace with database logic if required
    res.json( title );
  } catch (error) {
    res.status(500).json({ message: "Error fetching section title", error });
  }
});

module.exports = router;
