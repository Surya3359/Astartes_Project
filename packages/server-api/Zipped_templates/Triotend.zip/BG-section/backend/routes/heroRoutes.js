const express = require('express');
const multer = require('multer');
const Hero = require('../models/heroModel'); // MongoDB Schema
const router = express.Router();

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Local uploads folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname); // Unique filename
  },
});

const upload = multer({ storage });

// Fetch Hero Content
router.get('/', async (req, res) => {
  try {
    const hero = await Hero.findOne(); // Fetch the first document
    res.json(hero);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Update Hero Content
router.post('/', upload.single('heroImg'), async (req, res) => {
  const { title, subtitle, videoLink } = req.body;

  try {
    const image = req.file ? `/uploads/${req.file.filename}` : null; // New image path
    let hero = await Hero.findOne();

    if (hero) {
      hero.title = title || hero.title;
      hero.subtitle = subtitle || hero.subtitle;
      hero.videoLink = videoLink || hero.videoLink;
      if (image) hero.image = image;

      await hero.save();
    } else {
      hero = new Hero({
        title,
        subtitle,
        videoLink,
        image: image || '',
      });
      await hero.save();
    }

    res.json(hero);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
