import React from 'react';
import HeroSection from './components/HeroSection';
import PortfolioSection from './components/PortfolioSection';
// import './styles.css'; // Import the CSS file for global styling

const App = () => {
  return (
    <div>
      <HeroSection />
      <PortfolioSection />
    </div>
  );
};

export default App;
