import React, { useState, useEffect } from 'react';
import axios from 'axios';


const HeroSection = () => {
  const [heroData, setHeroData] = useState(null);

  useEffect(() => {
    const fetchHeroData = async () => {
      try {
        const { data } = await axios.get('http://localhost:5000/api/hero');
        console.log('Fetched Hero Data:', data); // Debug log
        setHeroData(data);
      } catch (error) {
        console.error('Error fetching hero data:', error); // Debug log
      }
    };

    fetchHeroData();
  }, []);

  if (!heroData) {
    return <p>Loading...</p>;
  }

  return (
    <section id="hero" className="hero-section">
      <div className="container">
        <div className="left">
          <h1>{heroData.title}</h1>
          <p>{heroData.subtitle}</p>
          <div className="btn-container">
            <a href="#" className="btn">Get Started</a>
            {/* <a href={heroData.videoLink} className="btn watch-video">
              <span>Watch Video</span>
            </a> */}
          </div>
        </div>
        <div className="right">
          <img 
            src={`http://localhost:5000${heroData.image}`} 
            alt="Hero" 
            onError={(e) => { e.target.src = '/uploads/default-hero.png'; }} // Fallback for broken images
          />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
