import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaSearchPlus } from 'react-icons/fa'; // Font Awesome icons

const PortfolioSection = () => {
  const [portfolioItems, setPortfolioItems] = useState([]);
  const [categories, setCategories] = useState([]); // For dynamic filters
  const [sectionTitle, setSectionTitle] = useState(''); // For dynamic section title
  const [filteredItems, setFilteredItems] = useState([]);
  const [activeFilter, setActiveFilter] = useState('*'); // Initially show all items
  const [imagePreview, setImagePreview] = useState(null); // To track the current preview
  const [currentIndex, setCurrentIndex] = useState(null); // To track the current image index

  // Fetch portfolio data and dynamic elements
  useEffect(() => {
    const fetchPortfolioData = async () => {
      try {
        const portfolioResponse = await axios.get('http://localhost:5000/api/portfolio');
        setPortfolioItems(portfolioResponse.data);
        setFilteredItems(portfolioResponse.data); // Initially show all items

        const categoriesResponse = await axios.get('http://localhost:5000/api/portfolio/categories');
        
        setCategories(categoriesResponse.data);

        // Dynamic Section Title (optional: fetched from backend or static for now)
        const secTitleResponse = await axios.get('http://localhost:5000/api/portfolio/title');
        setSectionTitle(secTitleResponse.data);
      } catch (error) {
        console.error('Error fetching portfolio data:', error);
      }
    };

    fetchPortfolioData();
  }, []);

  // Handle filter changes
  const handleFilterChange = (filter) => {
    setActiveFilter(filter);
    if (filter === '*') {
      setFilteredItems(portfolioItems); // Show all items
    } else {
      const filtered = portfolioItems.filter(item => item.category.toLowerCase() === filter.toLowerCase());
      setFilteredItems(filtered);
    }
  };

    // Handle opening image preview
    const openImagePreview = (index) => {
      setImagePreview(filteredItems[index].image);
      setCurrentIndex(index);
    };
  
    // Handle closing the image preview
    const closeImagePreview = () => {
      setImagePreview(null);
      setCurrentIndex(null);
    };
  
    // Navigate to next image
    const nextImage = () => {
      if (currentIndex !== null && currentIndex < filteredItems.length - 1) {
        setCurrentIndex(currentIndex + 1);
        setImagePreview(filteredItems[currentIndex + 1].image);
      }
    };
  
    // Navigate to previous image
    const prevImage = () => {
      if (currentIndex !== null && currentIndex > 0) {
        setCurrentIndex(currentIndex - 1);
        setImagePreview(filteredItems[currentIndex - 1].image);
      }
    };

  return (
    <section id="portfolio" className="portfolio-section">
      <div className="container">
        <div className="section-title">
          <h2>{sectionTitle}</h2> {/* Render dynamic section title */}
        </div>

        {/* Portfolio Filters */}
        <div className="portfolio-filters">
          <ul>
            <li
              onClick={() => handleFilterChange('*')}
              className={activeFilter === '*' ? 'active' : ''}
            >
              All
            </li>
            {categories.map((category, index) => (
              <li
                key={index}
                onClick={() => handleFilterChange(category)}
                className={activeFilter === category ? 'active' : ''}
              >
                {category}
              </li>
            ))}
          </ul>
        </div>

        {/* Portfolio Items */}
        <div className="portfolio-container">
          {filteredItems.map((item, index) => (
            <div key={index} className="portfolio-item">
              <img src={`http://localhost:5000${item.image}`} alt={item.title} onClick={() => openImagePreview(index)} />
              <div className="portfolio-info">
                <h4>{item.title}</h4>
                <p>{item.description}</p>
                {/* <a href={`http://localhost:5000${item.image}`} className="preview-link">
                  <FaSearchPlus />
                </a> */}
              </div>
            </div>
          ))}
        </div>

          {/* Image Preview Modal */}
      {imagePreview && (
        <div className="image-preview-modal">
          <div className="modal-content">
            <button className="close-btn" onClick={closeImagePreview}>X</button>
            <div className="image-wrapper">
              <img src={`http://localhost:5000${imagePreview}`} alt="Preview" />
            </div>
            <div className="navigation-buttons">
              <button onClick={prevImage} disabled={currentIndex === 0}>Previous</button>
              <button onClick={nextImage} disabled={currentIndex === filteredItems.length - 1}>Next</button>
            </div>
          </div>
        </div>
      )}
        
      </div>
    </section>
  );
};

export default PortfolioSection;
